IGME 309  
Sofia Murphy  
Exercise 05  
09/29/2025

	  
	For this exercise the main issue I struggled with was parsing the data from the file into the arrays for the class. I had difficulty splitting the string that contained the line from the file, as C++ doesn’t have a built-in method to split strings based on specific characters. After researching online, I found two methods to complete this. One method would be to create a custom function to split the string, and the other would be to utilize istreamstring.   
I ultimately chose the second method, as it would be much simpler than making my own function. Since istreamstring would split the string based on whitespace, I was able to easily extract the data type, and the data itself from the string. After doing this, I then added the data to their respective arrays, and was able to complete the exercise.   
Overall I found this exercise to be somewhat challenging, as I wasn’t used to loading .obj files in C++, and I also found it difficult to work with the .obj file formatting. This assignment presented me with some issues, but I feel was a good reintroduction to loading files, as well as displaying how it can be related to OpenGL.  