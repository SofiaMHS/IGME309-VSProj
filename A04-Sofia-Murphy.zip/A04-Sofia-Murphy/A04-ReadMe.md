How to control the robot:

- W → move up the list of limbs  
- S → move down the list of limbs  
- A → rotate the angle counterclockwise  
- D → rotate the angle clockwise