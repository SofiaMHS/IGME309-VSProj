IGME 309  
Sofia Murphy  
Exercise 06  
10/06/2025

	  
	The main issue I struggled with for this assignment was the syntax for the draw function. While I was able to set up the buffers correctly, there were some parts of the implementation for the draw function that I initially missed. For instance, I forgot to clean up the buffers at the end of the draw method, which resulted in them not executing correctly initially. Additionally, I had some issues with formatting the calls for the buffers, particularly glDrawElements() call, since I needed to utilize the triNum variable in order to calculate the correct number of indices.  
	Other than those issues, I was able to correctly implement the buffers into my project. This exercise I feel served as a good introduction to the topic of buffers, and allowed me to explore the methods to properly create, use, and dispose of them. 