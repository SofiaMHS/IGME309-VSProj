#pragma once
unsigned int testData_vert_num = 5;
unsigned int testData_tri_num = 3;

float testData_vertices[] = {
	2.0f, 4.0f,
	4.0f, 8.0f,
	6.0f, 6.0f,
	7.0f, 3.0f,
	5.0f, 3.0f
};

unsigned int testData_indices[] = {
	0, 1, 2,
	0, 2, 4,
	4, 2, 3
};