Usage:

Press "c" to switch the camera controls between first-person mode and focus mode. 
In first-person mode, moving the mosue while pressing the MMB down rotates the camera, and "wasd" moves the camera. 
In focus mode, alt+LMB rotates the camera, alt+MMB pans the camera, and alt+RMB zooms the camera. 

Press "v" to switch the rendering between shaded mode and wireframe mode. 

This example loads the bunny model from the obj file (Mesh/bunny2k.obj). 
The vNum displayed on the screen is the number of vertices of the bunny.
The tNum displayed on the screen is the number of triangles of the bunny.