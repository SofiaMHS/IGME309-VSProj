IGME 309  
Sofia Murphy  
Exercise 10  
11/10/2025

	For this exercise, the main struggle I had was with the GL\_LINE\_LOOP. Initially, I simply added the vertices of the wireframe cube out of order, and so the cube was not drawn properly. As such, I needed to find a combination of vertices which would allow me to draw the cube as it was pictured in the assignment examples.   
	The method to compute the max and min x, y, z values wasn’t very difficult for me to implement. I simply looped through the list of vertices and compared the x, y, and z values to the current max and min, and adjusted the max/min based on those values.   
	Overall, the exercise was a good way to practice creating bounding boxes, as well as creating the algorithms to draw them. 