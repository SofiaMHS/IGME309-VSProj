IGME 309  
Sofia Murphy  
Exercise 11  
11/17/2025

	For this assignment, I implemented three methods for cubic bezier easing. The first method would perform the cubic bezier formula. The second method would find x based on two input x values. The third method would complete the cubic bezier easing formula, using both the second and first methods.  
	The main part of this exercise I struggled with was finding the correct values and implementation of the cubic bezier easing method. Initially, I believed I would need to utilize a float variable to alter the transformations on the box. However, upon further research I realized I would simply need to adjust the value of the float t, which was being used to find the position of the box. This would then allow me to properly implement cubic bezier easing. The next step in this process was to find the appropriate values for my cubic bezier function. After researching cubic bezier easing online, I found a few helpful sources which illustrated what the ranges of cubic bezier functions generally were. I also looked into what specific effects I could design based on the values I input into the cubic bezier easing function.   
